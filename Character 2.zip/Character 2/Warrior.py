from Character import Characters


# Class fille de Character

class Warrior(Characters):

    def __init__(self, name, RPGClass="Warrior"):
        super().__init__(c_name=name, c_RPGClass=RPGClass)
        self.life = 100
        self.strength = 10
        self.agility = 8
        self.wit = 3
        self._RPGClass = "Warrior"

    def get_attack(self, Weapon="Hand"):
        self.Weapon = Weapon
        if self.Weapon == "Sword" or self.Weapon == "Hammer":
            print("[{}]: RRRRrrrrrrrrrrrr".format(self.name))
            print("[{}]:I'll crush you with my {}!".format(self.name, Weapon))
        else:
            print("[{}]:Give me a really weapon !! rrrr".format(self.name))

    def moveBack(self):
        print("[{}]:Moves back like a bad boys ".format(self.name))

    def moveForward(self):
        print("[{}]:Moves forward like a bad boys ".format(self.name))

    def moveLeft(self):
        print("[{}]:Moves left like a bad boys ".format(self.name))

    def moveRight(self):
        print("[{}]:Moves right like a bad boys ".format(self.name))

Warrior1 = Warrior("Guy")
print(Warrior1)
Warrior1.get_attack("Hand")
Warrior1.moveLeft()
Warrior1.unsheathe()