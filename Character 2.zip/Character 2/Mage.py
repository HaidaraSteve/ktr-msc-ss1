from Character import Characters


# Class fille de Character

class Mage(Characters):

    def __init__(self, name, RPGClass="Mage"):
        super().__init__(c_name=name, c_RPGClass=RPGClass)
        self.life = 70
        self.strength = 3
        self.agility = 10
        self.wit = 10
        self._RPGClass = "Mage"


    def get_attack(self, Weapon="Hand"):
        self.Weapon = Weapon
        if self.Weapon == "Magic" or self.Weapon == "Wand":
            print("[{}]: RRRRrrrrrrrrrrrr".format(self.name))
            print("[{}]: Feel the power of my {}!".format(self.name, Weapon))
        else:
            print("[{}]:Give me a magic potion !!".format(self.name))

    def moveBack(self):
        print("[{}]:Moves back furtively  ".format(self.name))

    def moveForward(self):
        print("[{}]:Moves forward furtively  ".format(self.name))

    def moveLeft(self):
        print("[{}]:Moves left furtively  ".format(self.name))

    def moveRight(self):
        print("[{}]:Moves right furtively  ".format(self.name))

Mage1 = Mage ("Zalazan", "Magic")
print(Mage1)
Mage1.get_attack()
Mage1.moveLeft()
Mage1.unsheathe()
