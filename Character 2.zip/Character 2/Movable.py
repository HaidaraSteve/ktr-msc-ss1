from abc import ABCMeta, abstractmethod


class IMovable(metaclass=ABCMeta):

    @abstractmethod
    def moveRight(self,*args):
        pass


    @abstractmethod
    def moveLeft(self):
        pass

    @abstractmethod
    def moveBack(self):
        pass

    @abstractmethod
    def moveForward(self):

        pass
