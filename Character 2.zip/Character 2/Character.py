from abc import ABC

from Movable import IMovable

from typing import final

class Characters(IMovable, ABC):

    def __init__(self, c_name, c_RPGClass="Character"):
        self.name = str(c_name)
        c_RPGClass = "Character"
        self._RPGClass = c_RPGClass
        self.life = 50
        self.agility = 2
        self.strength = 2
        self.wit = 2
        self.Weapon="Hand"

    @final
    def unsheathe(self):
        print(f'[{self.name}]:unsheathes his weapon')

    def get_attack(self,Weapon):

        print("{}:Attaque \nCrie: Rrrrrrrrr".format(self.name))


    def __repr__(self):
        return "Classe:[{}]\nnom:{}\nPV:{}\nAGI:{}\nSTR:{}\nWIT:{}".format(self._RPGClass, self.name, self.life,
                                                                           self.agility, self.strength, self.wit)
    def moveBack(self):
        print("Moves back like a peasants ")

    def moveForward(self):
        print("Moves forward like a peasants")

    def moveLeft(self):
        print("Moves left like a peasants")

    def moveRight(self):
        print("Moves Right like a peasants")

#charact1 = Characters("Mathieu")
#charact1.moveBack()
# print(charact1)
''''
print(charact1.name)
print(charact1.life)
print(charact1.agility)
print(charact1.strength)
print(charact1.wit)
print(charact1.RPGClass)
charact1.attack()

'''
